# MCuNovo Gene Selector
Select best protein codeing genes  from models Generated from MAKER2, Cufflinks and any de novo assembling programs. Previously we published a paper describing how it works. In that paper, we call it MCOT.
 
Cao, X.; Jiang, H. Integrated Modeling of Protein-Coding Genes in the Manduca Sexta Genome Using RNA-Seq Data from the Biochemical Model Insect. Insect Biochemistry and Molecular Biology 2015, 62, 210.
http://www.sciencedirect.com/science/article/pii/S0965174815000144

##This program will be availabe later, and is under devlopment.
Currently, I can only write code in python. Luckily, I've alreadly had a program works pretty good, now I need to make it easier to use, and runs faster.

##Download MCuNono
Just click the "clone or download" button, and click "Download ZIP".
Or, clik this link directly.
https://github.com/ATPs/MCuNovo/archive/master.zip

##Name MCuNovo
This name is from MAKER, Cufflinks and de novo.

##Let's wait and see what will happen later on.
